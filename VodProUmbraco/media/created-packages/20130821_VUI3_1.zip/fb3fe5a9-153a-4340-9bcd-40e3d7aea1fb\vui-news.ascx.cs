﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VUI.VUI3.classes;
using umbraco.MacroEngines;
using System.Configuration;

namespace VUI.usercontrols
{
    public partial class vui_news : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            DynamicNode services = new DynamicNode(Int32.Parse(ConfigurationManager.AppSettings["VUI2_ServiceMastersRoot"].ToString()));
            ddService.Items.Add(new ListItem("","-1"));
            foreach (DynamicNode service in services.Descendants())
            {
                ddService.Items.Add(new ListItem(service.Name, service.Id.ToString()));
            }
        }

        protected void btnTweet_Click(object sender, EventArgs e)
        {
            VUI3News.TweetNews(txtStatus.Text);
        }


        protected void btnSaveNews_Click(object sender, EventArgs e)
        {

            string newsType = ddNewsType.SelectedValue;

            if (newsType.Equals(VUI3News.NEWSTYPE_SYSTEM))
            {
                VUI3News.AddNews(newsType: newsType, description: txtDescription.Text);
            }
            if (newsType.Equals(VUI3News.NEWSTYPE_BENCHMARK))
            {
                VUI3News.AddNews(newsType: newsType, relatedServiceId: Int32.Parse(ddService.SelectedValue), relatedService: ddService.Text, relatedPlatform: ddPlatform.SelectedValue, relatedDevice: ddDevice.SelectedValue);
            }
            if (newsType.Equals(VUI3News.NEWSTYPE_SCREENSHOT))
            {
                VUI3News.AddNews(newsType: newsType, ScreenshotCount: Int32.Parse(txtScreenshotCount.Text), relatedServiceId: Int32.Parse(ddService.SelectedValue), relatedService: ddService.Text, relatedPlatform: ddPlatform.SelectedValue, relatedDevice: ddDevice.SelectedValue);
            }
            if (newsType.Equals(VUI3News.NEWSTYPE_VERSION))
            {
                VUI3News.AddNews(newsType: newsType, version: txtVersion.Text, appStore: ddAppStore.SelectedValue, relatedPlatform: ddPlatform.SelectedValue, relatedDevice: ddDevice.SelectedValue);
            }
            if (newsType.Equals(VUI3News.NEWSTYPE_NEW))
            {
                VUI3News.AddNews(newsType: newsType, relatedServiceId: Int32.Parse(ddService.SelectedValue), relatedService: ddService.Text, description: txtDescription.Text);
            }
        }
    }
}