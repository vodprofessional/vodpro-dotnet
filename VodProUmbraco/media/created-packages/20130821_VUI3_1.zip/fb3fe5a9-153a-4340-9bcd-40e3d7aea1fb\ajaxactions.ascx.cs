﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using umbraco;
using umbraco.cms;
using umbraco.presentation;
using umbraco.BusinessLogic;
using umbraco.cms.businesslogic.web;
using umbraco.NodeFactory;
using umbraco.cms.businesslogic.member;
using umbraco.cms.businesslogic.propertytype;
using System.Web.Security;
using VUI.classes;
using VUI.VUI2.classes;
using VUI.VUI3.classes;

namespace VUI.usercontrols
{
    public partial class ajaxactions : System.Web.UI.UserControl
    {
        private VUIUser u;

        protected void Page_Load(object sender, EventArgs e)
        {
            string _action = Request.QueryString["a"];
            if (_action.Equals(ACTION_SEARCH_IMAGES))
            {
                SearchImages();
            }
            if (_action.Equals(ACTION_GET_LATEST_NEWS))
            {
                GetLatestNews();
            }

            if (_action.Equals(ACTION_LOGIN))
            {
                Login();
            }
            if (_action.Equals(ACTION_LOGOUT))
            {
                Logout();
            }
            if (_action.Equals(ACTION_RECOVER_PASSWORD))
            {
                RecoverPassword();
            }
            if (_action.Equals(ACTION_CHANGE_PASWORD))
            {
                ChangePassword();
            }
            if (_action.Equals(ACTION_GET_IMAGES_FOR_SERVICE))
            {
                GetImagesForService();
            //    MemberLogin();
            }
            if (_action.Equals(ACTION_RATE_SERVICE))
            {
                RateService();
            }
            if (_action.Equals(ACTION_FAVOURITE_IMAGE))
            {
                AddImageFavourite();
            }
            if (_action.Equals(ACTION_UNFAVOURITE_IMAGE))
            {
                DeleteImageFavourite();
            }

            if (_action.Equals(ACTION_FAVOURITE_SERVICE))
            {
                AddServiceFavourite();
            }
            if (_action.Equals(ACTION_UNFAVOURITE_SERVICE))
            {
                DeleteServiceFavourite();
            }


            if (_action.Equals(ACTION_GET_ALL_SERVICE_LIST))
            {
                GetAllServiceList();
            }
            if (_action.Equals(ACTION_GET_SERVICE_LIST_BY_NAME))
            {
                GetServiceListByName();
            }
            if (_action.Equals(ACTION_GET_SERVICE_LIST_BY_NAME_AND_PLATFORM))
            {
                GetServiceListByServiceNameAndPlatform();
            }
            if (_action.Equals(ACTION_GET_SERVICE_LIST_BY_PLATFORM))
            {
                GetServiceListByPlatform();
            }
        }

        private bool IsLoggedIn()
        {
            u = VUI3Utility.GetUser();
            return VUI3Utility.UserCanView(u);
        }

        private void GetLatestNews()
        {
            int numitems;
            string _numitems = Request["numitems"];
            Int32.TryParse(_numitems, out numitems);
            if (numitems == null || numitems == 0)
                numitems = 10;
            string json = VUI3News.GetNewsAsJson(numitems);
            Response.Write(json);
        }

        private void Login()
        {
            string prot = Request.ServerVariables["SERVER_PROTOCOL"];
            string user = Request["user"];
            string password = Request["pass"];
            if (VUI3Utility.MemberLogin(user, password))
            {
                Response.Write(@"{ ""response"":""valid"",""data"":""/vui3/"" }");
            }
            else
            {
                Response.Write(@"{ ""response"":""invalid"",""data"":""Incorrect username / password combination. Please try again"" }");
            }
        }

        private void Logout()
        {
            VUI3Utility.MemberLogout();
            Response.Write(@"{ ""response"":""valid"",""data"":""/vui3/"" }");
        }

        private void RecoverPassword()
        {
            string email = Request["email"];

            VUIfunctions.SendPwdResetEmail(email);

            Response.Write(@"{ ""response"":""valid"",""data"":""Your password has been reset and sent to the email address provided"" }");
        }

        private void ChangePassword()
        {
            if (IsLoggedIn())
            {
                string message;
                string valid = u.ChangePassword(Request["pwd"].ToString(), out message) ? "valid" : "invalid";

                Response.Write(@"{ ""response"":""" + valid + @""",""data"":""" + message + @""" }");
            }
        }

        private void SearchImages()
        {
            string service = Request["service"];
            string pagetype = Request["pagetype"];
            Response.Write(SearchImagesSingleton.Instance().FindImagesJSON(service, pagetype));
        }

        private void GetImagesForService()
        {
            // Make sure user is loggedin!!!

            int serviceid;
            if (Int32.TryParse(Request["service"], out serviceid))
            {
                Response.Write(VUIfunctions.ServiceWithImagesToJson(serviceid));
                // Response.Write(VUIfunctions.ImageListJson(serviceid));
            }
            else
            {
                Response.Write(VUIfunctions.ImageListJson(Request["service"]));
            }
        }

        private void AddServiceFavourite()
        {
            if (IsLoggedIn())
            {
                if (Request["id"] != null && !String.IsNullOrEmpty(Request["id"].ToString()))
                {
                    int id;
                    if (Int32.TryParse(Request["id"].ToString(), out id))
                    {
                        u.AddFavouriteService(id);
                        VUI3ServiceMaster sm = new VUI3ServiceMaster(id);
                        VUI3ServiceSnapshot snap = sm.GetSnapshot();
                        Response.Write(@"{ ""response"":""valid"",""data"": " + snap.AsJson() + " }");
                    }
                    else
                    {
                        Response.Write(@"{ ""response"":""invalid"",""data"":""Invalid service"" }");
                    }
                }
                else
                {
                    Response.Write(@"{ ""response"":""invalid"",""data"":""Invalid service"" }");
                }
            }
        }
        private void DeleteServiceFavourite()
        {
            if (IsLoggedIn())
            {
                if (Request["id"] != null && !String.IsNullOrEmpty(Request["id"].ToString()))
                {
                    int id;
                    if (Int32.TryParse(Request["id"].ToString(), out id))
                    {
                        u.DeleteFavouriteService(id);
                        Response.Write(@"{ ""response"":""valid"",""data"":""Service Deleted"" }");
                    }
                    else
                    {
                        Response.Write(@"{ ""response"":""invalid"",""data"":""Invalid service"" }");
                    }
                }
                else
                {
                    Response.Write(@"{ ""response"":""invalid"",""data"":""Invalid service"" }");
                }
            }
        }



        private void DeleteImageFavourite()
        {
            bool ret = false;
            if (IsLoggedIn())
            {
                int imageId = 0;
                try
                {
                    if (Int32.TryParse(Request["id"].ToString(), out imageId))
                    {
                        if (Request["collection"] != null && !String.IsNullOrEmpty(Request["collection"].ToString()))
                        {
                            ret = u.DeleteFavouriteImage(imageId, Request["collection"].ToString());
                        }
                        else
                        {
                            ret = u.DeleteFavouriteImage(imageId);
                        }

                        if (ret)
                        {
                            Response.Write(@"{ ""response"":""valid"",""data"":""Image Deleted"" }");
                        }
                        else
                        {
                            Response.Write(@"{ ""response"":""invalid"",""data"":""Could not delete image"" }");
                        }
                    }
                    else
                    {
                        Response.Write(@"{ ""response"":""invalid"",""data"":""Invlaid image"" }");
                    }
                }
                catch (Exception e)
                {
                    Response.Write(@"{ ""response"":""invalid"",""data"":""Invalid image"" }");
                }
            }
        }


        private void AddImageFavourite()
        {
            if (IsLoggedIn())
            {
                int imageId = 0;

                try
                {
                    if (Int32.TryParse(Request["id"].ToString(), out imageId))
                    {
                        if (Request["collection"] != null && !String.IsNullOrEmpty(Request["collection"].ToString()))
                        {
                            u.AddFavouriteImage(imageId, Request["collection"].ToString());
                        }
                        else
                        {
                            u.AddFavouriteImage(imageId);
                        }
                        VUI3Screenshot s = VUI3Utility.GetScreenshot(imageId);
                        Response.Write(@"{ ""response"":""valid"",""data"":" + s.AsJson() + " }");
                    }
                    else
                    {
                        Response.Write(@"{ ""response"":""invalid"",""data"":""Invalid Image"" }");
                    }
                }
                catch (Exception e) 
                {
                    Response.Write(@"{ ""response"":""invalid"",""data"":""Invalid Image"" }");
                }
            }
            else
            {
                Response.Write(@"{ ""response"":""invalid"",""data"":""Not Logged In"" }");
            }
            // u.DeleteFavouriteImage(2881);
        }

        /// <summary>
        /// Deprecated
        /// </summary>
        private void FavouriteImage()
        {
            int imageid = -1;

            if (Int32.TryParse(Request["imageid"], out imageid))
            {
                Response.Write(VUIfunctions.FavouriteImage(imageid, Request["action"]));
            }
        }

        private void RateService()
        {
            int rating = -1;
            int serviceid = -1;

            if (Int32.TryParse(Request["rating"], out rating) && Int32.TryParse(Request["serviceid"], out serviceid))
            {
                Response.Write(VUIfunctions.RateService(serviceid, rating));
            }
        }


        private void GetServiceListByName()
        {
            string serviceName = Request["service"];
            if (!String.IsNullOrEmpty(serviceName))
            {
                Response.Write(VUIfunctions.ServiceListByNameToJson(serviceName));
            }
        }

        private void GetAllServiceList()
        {
            Response.Write(VUI3Utility.AllServicesSimple().AsJson());
        }

        private void Deprecated_GetAllServiceList()
        {
            Response.Write(VUIfunctions.ServiceListByAllPlatformsToJson());
        }

        private void GetServiceListByPlatform()
        {
            int platformId = -1;
            if (Int32.TryParse(Request["platformid"], out platformId))
            {
                Response.Write(VUIfunctions.ServiceListByPlatformToJson(platformId));
            }
        }

        private void GetServiceListByServiceNameAndPlatform()
        {
            int platformId = -1;
            string serviceName = Request["service"];
            if (!String.IsNullOrEmpty(serviceName) && Int32.TryParse(Request["platformid"], out platformId))
            {
                Response.Write(VUIfunctions.ServiceListByNameAndPlatformToJson(serviceName, platformId));
            }
        }
        
        const string ACTION_SEARCH_IMAGES = "ss";
        const string ACTION_GET_IMAGES_FOR_SERVICE = "si";
        const string ACTION_GET_SERVICE_LIST_BY_NAME = "sn";
        const string ACTION_GET_SERVICE_LIST_BY_PLATFORM = "sp";
        const string ACTION_GET_SERVICE_LIST_BY_NAME_AND_PLATFORM = "snp";
        const string ACTION_GET_ALL_SERVICE_LIST = "sa";
        const string ACTION_RATE_SERVICE = "rs";
        const string ACTION_FAVOURITE_IMAGE = "fi";
        const string ACTION_UNFAVOURITE_IMAGE = "fu";
        const string ACTION_GET_LATEST_NEWS = "ln";
        const string ACTION_LOGIN = "lo";
        const string ACTION_LOGOUT = "lu";
        const string ACTION_RECOVER_PASSWORD = "pr";
        const string ACTION_GET_FAVOURITE_SERVICES = "fs";
        const string ACTION_GET_FAVOURITE_SCREENSHOTS = "fc";
        const string ACTION_CHANGE_PASWORD = "cp";
        const string ACTION_FAVOURITE_SERVICE = "fsv";
        const string ACTION_UNFAVOURITE_SERVICE = "fuv";
    }
}