﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using umbraco.BusinessLogic;
using umbraco.cms.businesslogic.web;
using umbraco.MacroEngines;
using umbraco.NodeFactory;
using System.Xml.XPath;
using VUI.classes;
using VUI.VUI2.classes;
using VUI.VUI3.classes;
using System.Text;

namespace VUI.usercontrols
{
    public partial class vui_importer : System.Web.UI.UserControl
    {
        int umb_vuiFolderRoot = 0;
        string VUI_importfolder = String.Empty;
        string VUI_mediafolder = String.Empty;        
        string VUI_importtempfolder = String.Empty;
        int VUI_pagetypelist = -1;
        int VUI_ScoringPageTypes = -1;
        int VUI_BenchmarkDevicesList = -1;

        int VUI_maxwidth_lg = 0;
        int VUI_maxwidth_th = 0;
        int VUI_maxwidth_md = 0;
        int VUI_maxwidth_full = 0;
        
        const string VUI_FOLDERTYPE = "VUI_Folder";
        const string VUI_IMAGETYPE = "VUI_Image";
        const string VUI_FULL_FOLDER = @"full";
        const string VUI_LG_FOLDER = @"lg";
        const string VUI_MD_FOLDER = @"md";
        const string VUI_TH_FOLDER = @"th";


        DirectoryInfo fol_full;
        DirectoryInfo fol_lg;
        DirectoryInfo fol_md;
        DirectoryInfo fol_th;


        User u = new User("websitecontentuser");

        protected void Page_Load(object sender, EventArgs e)
        {
            umb_vuiFolderRoot = Int32.Parse(ConfigurationManager.AppSettings["umb_vuiFolderRoot"].ToString());
            VUI_importfolder = ConfigurationManager.AppSettings["VUI_importfolder"].ToString();
            VUI_mediafolder = ConfigurationManager.AppSettings["VUI_mediafolder"].ToString();
            VUI_importtempfolder = ConfigurationManager.AppSettings["VUI_importtempfolder"].ToString();
            VUI_maxwidth_full = Int32.Parse(ConfigurationManager.AppSettings["VUI_maxwidth_full"].ToString());
            VUI_maxwidth_lg = Int32.Parse(ConfigurationManager.AppSettings["VUI_maxwidth_lg"].ToString());
            VUI_maxwidth_md = Int32.Parse(ConfigurationManager.AppSettings["VUI_maxwidth_md"].ToString());
            VUI_maxwidth_th = Int32.Parse(ConfigurationManager.AppSettings["VUI_maxwidth_th"].ToString());
            VUI_pagetypelist = Int32.Parse(ConfigurationManager.AppSettings["VUI_pagetypelist"].ToString());
            VUI_ScoringPageTypes = Int32.Parse(ConfigurationManager.AppSettings["VUI_ScoringPageTypes"].ToString());
            VUI_BenchmarkDevicesList = Int32.Parse(ConfigurationManager.AppSettings["VUI_BenchmarkDevicesList"].ToString());

            if (!IsPostBack)
            {
                XPathNodeIterator iterator = umbraco.library.GetPreValues(VUI_pagetypelist);
                iterator.MoveNext(); //move to first
                XPathNodeIterator preValues = iterator.Current.SelectChildren("preValue", "");

                while (preValues.MoveNext())
                {
                    string value = preValues.Current.Value;
                    string id = preValues.Current.GetAttribute("id", "");
                    litPageTypes.Text += @"<li data-id=""" + id + @""" class=""droppable ui-pagetype"">" + value + @" (<span class=""count"">0</span>)<span class=""img-data"" data-id=""" + id + @"""></span></li>";
                }

                PopulateServiceDD();
                
                /// TODO 
                /// Populate DD, and write even thandler
                iterator = umbraco.library.GetPreValues(VUI_BenchmarkDevicesList);
                iterator.MoveNext(); //move to first
                preValues = iterator.Current.SelectChildren("preValue", "");

                StringDictionary vals = new StringDictionary();

                while (preValues.MoveNext())
                {
                    ddDevice.Items.Add(new ListItem(preValues.Current.Value, preValues.Current.GetAttribute("id", "")));
                }
            }
        }


        protected void ClearWorkPackageImages(object sender, EventArgs e)
        {
            string wpi = txtWorkpackageid.Text;

            DocumentType dt = DocumentType.GetByAlias("VUI2Analysis");

            List<Document> analyses = Document.GetDocumentsOfDocumentType(dt.Id).ToList().Where(d => d.getProperty("workPackageID").Value.ToString().Equals(wpi)).ToList();

            foreach(Document a in analyses)
            {
                if(a.HasChildren)
                {
                    foreach(Document c in a.Children)
                    {
                        c.delete(true);
                    }
                }
            }
        }


        protected void ImportAnalysesFromDB(object sender, EventArgs e)
        {
            Importer.InitFeatureMaps();

            string wpi = txtWorkpackageid.Text;
            List<AnalysisImport> analyses = AnalysisImporter.GetAnalysisRecords(wpi);
            foreach (AnalysisImport a in analyses)
            {
                string features = a.FeatureList;
                string[] featurelist = features.Split(',');
                List<int> featureids = new List<int>();
                foreach (string f in featurelist)
                {
                    if (!String.IsNullOrEmpty(f))
                    {
                        string mappedFeature = String.Empty;
                        mappedFeature = Importer.featureFeatureMap[f.Trim()];

                        int id = GetPreValID(2850, mappedFeature);
                        if (id != -1)
                        {
                            featureids.Add(id);
                        }
                    }
                }

                string hotfeatures = a.HotList;
                string[] hotfeaturelist = hotfeatures.Split(',');
                List<int> hotfeatureids = new List<int>();
                foreach (string f in hotfeaturelist)
                {
                    if (!String.IsNullOrEmpty(f))
                    {
                        string mappedFeature = String.Empty;
                        mappedFeature = Importer.featureFeatureMap[f.Trim()];
                        int id = GetPreValID(10097, mappedFeature);
                        if (id != -1)
                        {
                            hotfeatureids.Add(id);
                        }
                    }
                }


                Dictionary<string, object> nodeProps = new Dictionary<string, object>();
                nodeProps.Add("analysisDate", a.Timestamp);
                nodeProps.Add("benchmarkDate", a.Timestamp);
                nodeProps.Add("benchmarkDevice", GetPreValID(7489, a.TestingDevice));
                nodeProps.Add("serviceScore", featureids.Count);
                nodeProps.Add("serviceCapabilities", String.Join(",", featureids.ToArray()));
                nodeProps.Add("hotFeatures", String.Join(",", hotfeatureids.ToArray()));
                nodeProps.Add("workPackageID", wpi);

                int sid = a.GetServiceDocumentId();

                Document svc = new Document(sid);
                Document[] ansarr = svc.Children;

                if (ansarr.Length > 0)
                {
                    try
                    {
                        Document ans = svc.Children.ToList().First(an => an.Text.Equals(a.ImportDateTag));
                        if (ans != null)
                        {
                            UpdateVUINodePublish(ans.Id, nodeProps, ans.Published);
                            continue;
                        }
                    } catch { ; }
                }
                
                
                if (a.ServiceIsPublic)
                {
                    CreateVUINode(a.ImportDateTag, sid, "VUI2Analysis", nodeProps);
                }
                else
                {
                    CreateVUINodeNoPublish(a.ImportDateTag, sid, "VUI2Analysis", nodeProps);
                }

                try
                {
                    Document sm = VUI3Utility.FindServiceMasterDocumentByName(a.ServiceName);
                    int smid = sm.Id;
                    string pd = a.Platform;
                    if (!String.IsNullOrEmpty(a.Device))
                    {
                        pd = pd + " / " + a.Device;
                    }
                    string description = String.Format(@"New benchmark score for {0} on {1}", new object[] { a.ServiceName, pd });
                    VUI3News.AddNews(VUI3News.NEWSTYPE_BENCHMARK, relatedServiceId: smid, relatedService: a.ServiceName, relatedPlatform: a.Platform, relatedDevice: a.Device, description: description);
                }
                catch (Exception ex)
                {
                    string m = ex.Message;
                }

            }
        }

        protected int GetPreValID(int dataTypeId, string checkString)
        {
            // This is horrible - get the PreVal for "Paid by PayPal"
            int preValId = -1;
            string status = String.Empty;
            XPathNodeIterator statusRoot = umbraco.library.GetPreValues(dataTypeId);
            statusRoot.MoveNext(); //move to first
            XPathNodeIterator preValues = statusRoot.Current.SelectChildren("preValue", "");
            while (preValues.MoveNext())
            {
                if (preValues.Current.Value.ToLower().Equals(checkString.ToLower()))
                {
                    status = preValues.Current.GetAttribute("id", "");
                    break;
                }
            }
            if(Int32.TryParse(status, out preValId))
            {
                return preValId;
            }
            return preValId;
        }


        protected void SetAllHideHotFeatures(object sender, EventArgs e)
        {
            DynamicNode node = new DynamicNode(Utility.GetConst("VUI2_rootnodeid"));
            List<DynamicNode> analyses = node.Descendants(Utility.GetConst("VUI2_analysistype")).Items.ToList();
            Response.Write("Analyses: " + analyses.Count());
            foreach (DynamicNode analysis in analyses)
            {
                Document n = new Document(analysis.Id);
                n.getProperty("hideHotFeatures").Value = 1;
                n.Save();
                n.Publish(u);
                umbraco.library.UpdateDocumentCache(n.Id);
            }
        }


        protected void ClearAllPageTypes(object sender, EventArgs e)
        {
            DynamicNode node = new DynamicNode(umb_vuiFolderRoot);
            List<DynamicNode> images = node.Descendants(VUI_IMAGETYPE).Items;
            foreach (DynamicNode image in images)
            {
                Document n = new Document(image.Id);
                n.getProperty("pageType").Value = "";
                n.Save();
                n.Publish(u);
                umbraco.library.UpdateDocumentCache(n.Id);
            }

        }


        protected void PopulateServiceDD()
        {
            DynamicNode node = new DynamicNode(umb_vuiFolderRoot);
            List<DynamicNode> services = node.Descendants(VUI_FOLDERTYPE).Items
                                            .Where(n => n.GetProperty("folderLevel").Value.Equals(VUIfunctions.VUI_SERVICE))
                                            .OrderBy(n => n.Name)
                                            .ToList();
            foreach (DynamicNode service in services)
            {
                ServiceList.Items.Add(new ListItem(service.Name + "(" + service.Parent.Name + ")", service.Id.ToString()));
            }
        }

        protected void UpdateBenchmarkDetail(object sender, EventArgs e)
        {
            int device = -1;
            DateTime dt = calDate.SelectedDate;
            int rootId = -1;
            
            if(Int32.TryParse(txtServiceParent.Text, out rootId) &&  Int32.TryParse(ddDevice.SelectedValue, out device))
            {
                VUIfunctions.UpdateServiceBenchmarkDateDevice(rootId, dt, device);
                Response.Write("Updating services");
            }

        }


        protected void RegenerateVUIMetaData(object sender, EventArgs e)
        {
            lblMeta.Visible = false;
            lblMetaError.Visible = false;

            try
            {
                MetaData.RegenerateMetaData();
                SearchImagesSingleton.Instance();
                lblMeta.Visible = true;
            }
            catch (Exception ex)
            {
                lblMetaError.Text = ex.Message + ex.StackTrace;
                lblMetaError.Visible = true;
            }
        }


        protected void MigrateToVui2(object sender, EventArgs e)
        {
            Migrator mig = new Migrator();
            mig.Migrate();
            mig.MigratePart2();
        }


        protected void GenerateServiceMasterItems(object sender, EventArgs e)
        {
            lblMetaError.Text = GenerateServiceMasters.Generate();
            lblMetaError.Visible = true;
        }


        protected void GetImagesWithoutPageType()
        {
            DynamicNode node = new DynamicNode(umb_vuiFolderRoot);
            List<DynamicNode> images;
            if (!String.IsNullOrEmpty(ServiceList.SelectedValue))
            {
                int serviceid = 0;
                Int32.TryParse(ServiceList.SelectedValue, out serviceid);

                images = node.Descendants(VUI_IMAGETYPE).Items
                                                    .Where(n => n.Parent.Id == serviceid && (n.GetProperty("pageType") == null || String.IsNullOrEmpty(n.GetProperty("pageType").Value)))
                                                    .OrderBy(n => n.GetProperty("service").Value)
                                                    .OrderBy(n => n.GetProperty("device").Value)
                                                    .OrderBy(n => n.GetProperty("platform").Value)
                                                    .ToList();
            }
            else
            {
                images = node.Descendants(VUI_IMAGETYPE).Items
                                                    .Where(n => n.GetProperty("pageType") == null || String.IsNullOrEmpty(n.GetProperty("pageType").Value))
                                                    .OrderBy(n => n.GetProperty("service").Value)
                                                    .OrderBy(n => n.GetProperty("device").Value)
                                                    .OrderBy(n => n.GetProperty("platform").Value)
                                                    .ToList();
            }
            rptImageList.DataSource = images;
            rptImageList.DataBind();
        }


        private int prevParent = -1;

        protected void ImageList_Bound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                StringBuilder s = new StringBuilder(@"");
                DynamicNode imageNode = (DynamicNode)e.Item.DataItem;
                int parent = imageNode.Parent.Id;
                if (parent != prevParent)
                {
                    s.Append(@"<li class=""images-title"">" + imageNode.GetProperty("service").Value + " / " + imageNode.GetProperty("device").Value + " / " + imageNode.GetProperty("platform").Value + "</li>");
                
                    // Output checkbox list
                    s.Append(@"<ul class=""ui-service-capability"" data-serviceid=""" + parent + @""">");


                    Document serviceNode = new Document(parent);
                    string caps = "";
                    if (serviceNode.getProperty("serviceCapabilities") != null)
                    {
                        caps = serviceNode.getProperty("serviceCapabilities").Value.ToString();
                    }


                    XPathNodeIterator iterator = umbraco.library.GetPreValues(VUI_ScoringPageTypes);
                    iterator.MoveNext(); //move to first
                    XPathNodeIterator preValues = iterator.Current.SelectChildren("preValue", "");

                    while (preValues.MoveNext())
                    {
                        string value = preValues.Current.Value;
                        string id = preValues.Current.GetAttribute("id", "");
                        s.Append(@"<li>");
                        s.Append(@"<input id=""sc-" + parent + @"-" + id + @""" type=""checkbox"" value=""" + id + @"""");
                        
                        if(caps.Contains(id.ToString()))
                        {
                            s.Append(@" checked=""checked"" ");
                        }
                        s.Append(@"/>");
                        s.Append(@"<label for=""sc-" + parent + @"-" + id + @""">" + value + @"</label></li>");
                    }
                    s.Append(@"</ul>");
                }
                s.Append(@"<li><img src=""" + ResolveUrl(VUI_mediafolder) + @"load.png"" data-original=""" + ResolveUrl(VUI_mediafolder) + @"md/" + imageNode.GetProperty("imageFile").Value + @"""  data-id=""" + imageNode.Id + @""" class=""img-draggable lazy"" title=""PageType: " + imageNode.GetProperty("pageType").Value + @""" /></li>");
                Literal img = (Literal)e.Item.FindControl("litImage");
                img.Text = s.ToString();
                prevParent = parent;
            }
        }


        protected void btnShowNoTypePages_Click(object sender, EventArgs e)
        {
            GetImagesWithoutPageType();

            pnlOrgItems.Visible = true;
        }

        protected void btnRegnerateServiceScores_Click(object sender, EventArgs e)
        {
            VUIfunctions.UpdateAllServicePageTypesScore();
        }


        protected void UpdateData(object sender, EventArgs e)
        {

            // Update PageTypes
            string d = PageTypes.Text;
            string[] d1 = d.Split('/');

            foreach (string p in d1)
            {
                if (p.Contains(";"))
                {
                    string[] u = p.Split(';');

                    string pageType = u[0];
                    for (int i = 1; i < u.Length; i++)
                    {
                        int nodeId = Int16.Parse(u[i]);
                        Dictionary<string, string> imageProps = new Dictionary<string, string>();
                        imageProps.Add("pageType", pageType);
                        UpdateVUINode(nodeId, imageProps);
                    }
                }
            }

            // Upublish Images
            d = Bin.Text;
            d1 = d.Split('/');
            foreach (string p in d1)
            {
                if (p.Contains(";"))
                {
                    string[] u = p.Split(';');

                    string command = u[0];
                    for (int i = 1; i < u.Length; i++)
                    {
                        int nodeId = Int16.Parse(u[i]);
                        RemoveNode(nodeId);
                    }
                }
            }

            string[] capabilities = Capabilities.Text.Split(';');
            foreach (string servicecap in capabilities)
            {
                if (servicecap.Contains(":"))
                {
                    string[] c = servicecap.Split(':');
                    int serviceid = -1;
                    if(Int32.TryParse(c[0], out serviceid))
                    {
                        Dictionary<string, string> serviceProps = new Dictionary<string, string>();
                        serviceProps.Add("serviceCapabilities", c[1]);
                        UpdateVUINode(serviceid, serviceProps);
                    }
                }
            }


            umbraco.library.RefreshContent();

            GetImagesWithoutPageType();
            pnlOrgItems.Visible = true;

//            Dictionary<string, string> imageProps = new Dictionary<string, string>();
//            imageProps.Add("pageType", pageType);
//            UpdateVUINode(nodeId, imageProps);
        }

        private void RemoveNode(int nodeId)
        {
            // Unpublish 
            // Response.Write(@"Unpublishing: " + nodeId.ToString() + "");

            Document d = new Document(nodeId);
            d.UnPublish();
            umbraco.library.UnPublishSingleNode(nodeId);
            //umbraco.library.UpdateDocumentCache(nodeId);
        }

        /// <summary>
        /// Lithium Build Importer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Import(object sender, EventArgs e)
        {
            Importer.Import(ImportTag.Text);
        }

        protected void Import_Deprecated(object sender, EventArgs e)
        {
            /* Find the import folder root
             *  Root: \vui-import
             *                   \import-tag
             *                              \date
             *                                   \platform
             *                                            \device
             *                                                   \service
             *                             
             * Work through the folder structure, check/create the equivalent VUI_folder structure
             */
            try
            {
                Directory.Delete(Path.Combine(VUI_importfolder,VUI_importtempfolder,VUI_FULL_FOLDER), true);
                Directory.Delete(Path.Combine(VUI_importfolder, VUI_importtempfolder, VUI_LG_FOLDER), true);
                Directory.Delete(Path.Combine(VUI_importfolder, VUI_importtempfolder, VUI_MD_FOLDER), true);
                Directory.Delete(Path.Combine(VUI_importfolder, VUI_importtempfolder, VUI_TH_FOLDER), true);
            }
            catch (Exception ex)
            {
                ;
            }
            fol_full = Directory.CreateDirectory(Path.Combine(VUI_importfolder, VUI_importtempfolder, VUI_FULL_FOLDER));
            fol_lg = Directory.CreateDirectory(Path.Combine(VUI_importfolder, VUI_importtempfolder, VUI_LG_FOLDER));
            fol_md = Directory.CreateDirectory(Path.Combine(VUI_importfolder, VUI_importtempfolder, VUI_MD_FOLDER));
            fol_th = Directory.CreateDirectory(Path.Combine(VUI_importfolder, VUI_importtempfolder, VUI_TH_FOLDER));



            string importTag = ImportTag.Text;

            DirectoryInfo importroot = new DirectoryInfo(Path.Combine(VUI_importfolder,importTag));

            foreach (DirectoryInfo root in importroot.GetDirectories())
            {

                // Check the Children of the VUI root
                var vuiRoot = new Node(umb_vuiFolderRoot);
                string dateVal = root.Name;

                Nodes platformNodes = vuiRoot.Children;


                // Loop around platform directories in root
                foreach (DirectoryInfo platform in root.GetDirectories())
                {
                    string platformName = platform.Name.Trim();


                    bool platformExists = false;
                    int platformNodeId = 0;

                    // Check platform Nodes
                    foreach (Node n in platformNodes)
                    {
                        if (n.NodeTypeAlias.Equals(VUI_FOLDERTYPE) && n.Name.Trim().Equals(platformName))
                        {
                            platformExists = true;
                            platformNodeId = n.Id;
                        }
                    }
                    // Create new platform
                    if (!platformExists)
                    {
                        Lit1.Text += @" - Creating Platform: " + platformName + "<br/>";
                        Dictionary<string, object> folderProps = new Dictionary<string, object>();
                        folderProps.Add("folderLevel", "platform");
                        platformNodeId = CreateVUINode(platformName, umb_vuiFolderRoot, VUI_FOLDERTYPE, folderProps);
                    }

                    //Loop through Device folders
                    var platformRoot = new Node(platformNodeId);
                    Nodes deviceNodes = platformRoot.Children;
                    foreach (DirectoryInfo device in platform.GetDirectories())
                    {
                        bool deviceExists = false;
                        int deviceNodeId = 0;
                        string deviceName = device.Name.Trim();
                        foreach (Node n in deviceNodes)
                        {
                            if (n.NodeTypeAlias.Equals(VUI_FOLDERTYPE) && n.Name.Trim().Equals(deviceName))
                            {
                                deviceExists = true;
                                deviceNodeId = n.Id;
                            }
                        }
                        // Create new Device
                        if (!deviceExists)
                        {
                            Lit1.Text += @" -- Creating Device: " + deviceName + "<br/>";
                            Dictionary<string, object> folderProps = new Dictionary<string, object>();

                            int dirCount = device.GetDirectories().Count();

                            if(dirCount > 0)
                                folderProps.Add("folderLevel", "device");
                            else
                                folderProps.Add("folderLevel", "service");
                            deviceNodeId = CreateVUINode(deviceName, platformNodeId, VUI_FOLDERTYPE, folderProps);
                        }

                        ProcessImagesForFolder(device, deviceNodeId, importTag, dateVal, platformName, deviceName, String.Empty);

                        //Loop through Service folders
                        //var deviceRoot = new Node(deviceNodeId);
                        Document deviceDoc = new Document(deviceNodeId);
                        List<Document> serviceDocs = deviceDoc.Children.ToList<Document>();
                        // Nodes serviceNodes = deviceRoot.Children;
                        foreach (DirectoryInfo service in device.GetDirectories())
                        {
                            bool serviceExists = false;
                            int serviceNodeId = 0;
                            string serviceName = service.Name.Trim();
                            //foreach (Node n in serviceNodes)
                            foreach(Document n in serviceDocs)
                            {
                                if (n.ContentType.Text.Equals(VUI_FOLDERTYPE) && n.Text.Trim().Equals(serviceName))
                                {
                                    serviceExists = true;
                                    serviceNodeId = n.Id;
                                }
                            }
                            // Create new Service
                            if (!serviceExists)
                            {
                                Lit1.Text += @" --- Creating Service: " + serviceName + "<br/>";
                                Dictionary<string, object> folderProps = new Dictionary<string, object>();
                                folderProps.Add("folderLevel", "service");
                                serviceNodeId = CreateVUINode(serviceName, deviceNodeId, VUI_FOLDERTYPE, folderProps);
                            }

                            // Finally, process any images
                            ProcessImagesForFolder(service, serviceNodeId, importTag, dateVal, platformName, deviceName, serviceName);
                        }
                    }
                }
            }
            // Copy Generated Images into media folder
            foreach (FileInfo f in fol_full.GetFiles())
            {
 //             Response.Write(f.FullName + " -> " + Path.Combine(Server.MapPath(VUI_mediafolder), VUI_FULL_FOLDER) + f.Name + " (" + Path.Combine(Server.MapPath(VUI_mediafolder), VUI_FULL_FOLDER, f.Name) + ")<Br/>");
                File.Copy(f.FullName, Path.Combine(Server.MapPath(VUI_mediafolder), VUI_FULL_FOLDER, f.Name), true);
            }
            foreach (FileInfo f in fol_lg.GetFiles())
            {
                File.Copy(f.FullName, Path.Combine(Server.MapPath(VUI_mediafolder), VUI_LG_FOLDER, f.Name), true);
            }
            foreach (FileInfo f in fol_md.GetFiles())
            {
                File.Copy(f.FullName, Path.Combine(Server.MapPath(VUI_mediafolder), VUI_MD_FOLDER, f.Name), true);
            }
            foreach (FileInfo f in fol_th.GetFiles())
            {
                File.Copy(f.FullName, Path.Combine(Server.MapPath(VUI_mediafolder), VUI_TH_FOLDER, f.Name), true);
            }
        }



        protected void ProcessImagesForFolder(DirectoryInfo folder, int nodeId, string importTag, string dateVal, string name1, string name2, string name3)
        {
            FileInfo[] images = folder.GetFiles();

            foreach (FileInfo image in images)
            {
                string imageName = String.Empty;
                if (!String.IsNullOrEmpty("name3"))
                {
                    imageName = (dateVal + "-" + name1 + "-" + name2 + "-" + name3 + "-" + image.Name).Replace(' ', '-');
                }
                else
                {
                    imageName = (dateVal + "-" + name1 + "-" + name2 + "-" + image.Name).Replace(' ', '-');
                }

                if (!image.Extension.Contains("jpg"))
                {
                    Regex re = new Regex(@"\.[A-z]+$");
                    imageName = re.Replace(imageName, ".jpg");
                }
                imageName.Replace(@"&", @"and");

                // File.Copy(image.FullName, Path.Combine(fol_full.FullName, imageName), true);

                Resize(image.FullName, Path.Combine(fol_full.FullName, imageName), VUI_maxwidth_full);
                //File.Copy(image.FullName, Path.Combine(fol_full.FullName, imageName), true);
                Resize(Path.Combine(fol_full.FullName, imageName), Path.Combine(fol_lg.FullName, imageName), VUI_maxwidth_lg);
                Resize(Path.Combine(fol_full.FullName, imageName), Path.Combine(fol_md.FullName, imageName), VUI_maxwidth_md);
                Resize(Path.Combine(fol_full.FullName, imageName), Path.Combine(fol_th.FullName, imageName), VUI_maxwidth_th);



                var serviceRoot = new Document(nodeId);
                bool serviceIsPublished = serviceRoot.Published;

                List<Document> imageNodes = serviceRoot.Children.ToList<Document>();
                bool imageExists = false;

                foreach (Document  n in imageNodes)
                {
                    if (n.ContentType.Text.Equals(VUI_IMAGETYPE) && n.Text.Trim().Equals(imageName))
                    {
                        imageExists = true;
                    }
                }

                if (!imageExists)
                {
                    Dictionary<string, object> imageProps = new Dictionary<string, object>();
                    imageProps.Add("platform", name1);
                    if (String.IsNullOrEmpty(name3))
                    {
                        imageProps.Add("service", name2);
                    }
                    else
                    {
                        imageProps.Add("device", name2);
                        imageProps.Add("service", name3);
                    }
                    imageProps.Add("vuidate", dateVal);
                    imageProps.Add("imageFile", imageName);
                    imageProps.Add("lgFile", imageName);
                    imageProps.Add("thFile", imageName);
                    imageProps.Add("importTag", importTag);

                    int imageId = CreateVUINodePublish(imageName, nodeId, VUI_IMAGETYPE, imageProps, serviceIsPublished);
                }
            }
        }



        private int CreateVUINode(string nodeName, int parentNode, string documentType)
        {
            return CreateVUINode(nodeName, parentNode, documentType, null);
        }

        private int CreateVUINode(string nodeName, int parentNode, string documentType, Dictionary<string, object> nodeProps)
        {
            return CreateVUINodePublish(nodeName, parentNode, documentType, nodeProps, true);
        }
        private int CreateVUINodeNoPublish(string nodeName, int parentNode, string documentType, Dictionary<string, object> nodeProps)
        {
            return CreateVUINodePublish(nodeName, parentNode, documentType, nodeProps, false);
        }

        private void UpdateVUINodePublish(int id, Dictionary<string, object> nodeProps, bool publish)
        {
            Document d = new Document(id);
            if (nodeProps != null)
            {
                foreach (string k in nodeProps.Keys)
                {
                    d.getProperty(k).Value = nodeProps[k];
                }
            }
            d.Save();
            if (publish)
            {
                d.Publish(u);
                umbraco.library.UpdateDocumentCache(d.Id);
            }
        }

        private int CreateVUINodePublish(string nodeName, int parentNode, string documentType , Dictionary<string, object> nodeProps, bool publish)
        {
            // The documenttype that should be used, replace 10 with the id of your documenttype
            DocumentType dt = DocumentType.GetByAlias(documentType);

            // The umbraco user that should create the document,
            // 0 is the umbraco system user, and always exists
            

            // Create the document
            Document d = Document.MakeNew(nodeName, dt, u, parentNode);
            if (nodeProps != null)
            {
                foreach(string k in nodeProps.Keys)
                {
                    d.getProperty(k).Value = nodeProps[k];
                }
            }
            d.Save();
            if (publish)
            {
                d.Publish(u);
                umbraco.library.UpdateDocumentCache(d.Id);
            }
            return d.Id;
        }


        private void UpdateVUINode(int nodeId, Dictionary<string, string> nodeProps)
        {
            User u = new User("websitecontentuser");
            Document d = new Document(nodeId);
            if (nodeProps != null)
            {
                foreach (string k in nodeProps.Keys)
                {
                    d.getProperty(k).Value = nodeProps[k];
                }
            }
            d.Save();
            d.Publish(u);
            umbraco.library.UpdateDocumentCache(d.Id);
        }


        public void Resize(string imageFile, string outputFile, int maxWidth)
        {
            using (var srcImage = System.Drawing.Image.FromFile(imageFile))
            {
                double scaleFactor = 0;

                if(srcImage.Width > maxWidth)
                {
                    scaleFactor = (double)maxWidth / (double)srcImage.Width;
                }
                else {
                    maxWidth = srcImage.Width;
                    scaleFactor = 1;
                }
                ImageCodecInfo jgpEncoder = GetEncoder(ImageFormat.Jpeg);
                System.Drawing.Imaging.Encoder myEncoder = System.Drawing.Imaging.Encoder.Quality;
                EncoderParameters myEncoderParameters = new EncoderParameters(1);
                EncoderParameter myEncoderParameter = new EncoderParameter(myEncoder, 60L);
                myEncoderParameters.Param[0] = myEncoderParameter;

                var newWidth = maxWidth;
                var newHeight = (int)(srcImage.Height * scaleFactor);
                using (var newImage = new Bitmap(newWidth, newHeight))
                using (var graphics = Graphics.FromImage(newImage))
                {
                    graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    graphics.InterpolationMode = InterpolationMode.Default;
                    graphics.PixelOffsetMode = PixelOffsetMode.Default;
                    graphics.DrawImage(srcImage, new Rectangle(0, 0, newWidth, newHeight));
                    newImage.Save(outputFile, System.Drawing.Imaging.ImageFormat.Jpeg);
                }                
            }
        }

        /// <summary>
        /// Resize and get orientation
        /// </summary>
        /// <param name="format"></param>
        /// <returns></returns>

        private ImageCodecInfo GetEncoder(ImageFormat format)
        {
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
            foreach (ImageCodecInfo codec in codecs)
            {
                if (codec.FormatID == format.Guid)
                {
                    return codec;
                }
            }
            return null;
        }


        protected void UpdateServiceAppStoreURLs(object sender, EventArgs e)
        {
            Dictionary<int, string> services = VUIDataFunctions.GetServiceAppStoreURLs();
            User u = new User("websitecontentuser");
            foreach (int serviceid in services.Keys)
            {
                Document s = new Document(serviceid);
                s.getProperty("appStoreURL").Value = services[serviceid];
                s.Save();
                if (s.Published)
                {
                    s.Publish(u);
                    umbraco.library.UpdateDocumentCache(serviceid);
                }

            }
        }

    }
}