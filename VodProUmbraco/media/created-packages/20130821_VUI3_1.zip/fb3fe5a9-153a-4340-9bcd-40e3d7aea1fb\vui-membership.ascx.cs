﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VUI.classes;
using System.Web.Security;
using umbraco.cms.businesslogic.member;
using System.Text;

namespace VUI.usercontrols
{
    public partial class vui_membership : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            bool showRegistrantButton = ConfigurationManager.AppSettings["MEM_allowSetAllAsRegistrants"].ToString().Equals("true");
            if(showRegistrantButton)
            {
                pnlRegistrant.Visible = true;
            }
        }

        protected void AddRegistrant_Click(object sender, EventArgs e)
        {
            MemberGroup mg = MemberGroup.GetByName("registrant");
            List<Member> ms = Member.GetAllAsList().ToList();
            foreach (Member m in ms)
            {
                m.AddGroup(mg.Id);
            }

            ConfigurationManager.AppSettings["MEM_allowSetAllAsRegistrants"] = "false";
        }

        protected void GetUsers(object sender, EventArgs e)
        {

            List<Member> admins = VUIfunctions.GetVUIAdmins();

            StringBuilder sb = new StringBuilder();
            sb.Append(@"<ul>");
            
            foreach (Member admin in admins)
            {
                sb.Append(@"<li>");
                sb.Append(admin.Id.ToString() + " - ");
                sb.Append(admin.getProperty("firstName").Value.ToString() + " " + admin.getProperty("lastName").Value.ToString() + " - " + admin.Email);
                List<Member> users = VUIfunctions.GetVUIUsersForAdmin(admin);
                if (users.Count > 0)
                {
                    sb.Append("<ul>");
                    foreach (Member user in users)
                    {
                        sb.Append(@"<li>");
                        sb.Append(user.Id.ToString() + " - ");
                        sb.Append(user.getProperty("firstName").Value.ToString() + " " + user.getProperty("lastName").Value.ToString() + " " + user.Email);
                        sb.Append(@"</li>");
                    }
                    sb.Append("</ul>");
                }
                sb.Append(@"</li>");
            }
            litUsers.Text = sb.ToString();
        }

    }
}