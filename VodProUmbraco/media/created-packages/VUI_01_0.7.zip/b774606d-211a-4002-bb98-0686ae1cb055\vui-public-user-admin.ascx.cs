﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VUI.classes;
using umbraco.cms.businesslogic.member;

namespace VUI.usercontrols
{
    public partial class vui_public_user_admin : System.Web.UI.UserControl
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (VUIfunctions.CurrentMemberIsVUIAdmin())
                {
                    GetVUIUsers();
                    plcUsers.Visible = true;
                }
            }
        }

        protected void ClearFormAndPopulateList()
        {
            txtVuiUserFirstname.Text = String.Empty;
            txtVuiUserLastname.Text = String.Empty;
            txtVuiEmail.Text = String.Empty;
            GetVUIUsers();
        }

        protected void GetVUIUsers()
        {
            List<Member> vuiusers = VUIfunctions.GetVUIUsersForAdmin(VUIfunctions.CurrentUser());
            rptVUIusers.DataSource = vuiusers;
            rptVUIusers.DataBind();
            
        }

        protected void VUIUser_Bound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Literal u = e.Item.FindControl("litUserDetails") as Literal;
                Member m = (Member)e.Item.DataItem;
                u.Text = m.Email;
            }
        }

        // For Admins - Create vui_user
        protected void CreateVUIUser(object sender, EventArgs e) 
        {
            string firstname = txtVuiUserFirstname.Text;
            string lastname = txtVuiUserLastname.Text;
            string email = txtVuiEmail.Text;

            bool isValid = true;

            if (!VUIfunctions.IsEmail(email))
            {
                errEmail.Text = "Enter a valid email address";
                errEmail.Visible = true;
                isValid = false;
            }
            if (String.IsNullOrWhiteSpace(firstname) || String.IsNullOrWhiteSpace(lastname))
            {
                errName.Text = "Enter the user's first and last name";
                errName.Visible = true;
                isValid = false;
            }
            if (isValid)
            {
                string retval = VUIfunctions.CreateVUIuser(firstname, lastname, email);
                if(retval.Equals(VUIfunctions.VUI_USERADMIN_STATUS_SUCCESS))
                {
                    ClearFormAndPopulateList();
                }
                else
                {
                    errGeneral.Text = retval;
                    errGeneral.Visible = true;
                }
            }
        }

        protected void DeleteVUIUser(object sender, EventArgs e) { }

        protected void EditVUIUser(object sender, EventArgs e) { }

        protected void ChangeOwnPassword() 
        {
            
        }


    }
}