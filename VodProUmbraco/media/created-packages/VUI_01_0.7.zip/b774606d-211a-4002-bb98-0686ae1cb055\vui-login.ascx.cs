﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VUI.classes;
using umbraco.cms.businesslogic.member;
using System.Web.Security;
using VUI.classes;


namespace VUI.usercontrols
{
    public partial class vui_login : System.Web.UI.UserControl
    {
        public const string MODE_FORM = "FORM";
        public const string MODE_INFO = "INFO";

        public string Mode { get; set; }
        string user_status = VUIfunctions.VUI_USERTYPE_NONE;

        protected void Page_Load(object sender, EventArgs e)
        {
            Member m = VUIfunctions.CurrentUser();

            if (m != null)
            {
                user_status = VUIfunctions.MemberVUIStatus(m);
            }

            if (Mode.Equals(MODE_FORM))
            {
                plcViewDetails.Visible = false;
                // 1. If User is logged in, don't show


                if (user_status.Equals(VUIfunctions.VUI_USERTYPE_NONE))
                {
                    plcVUILogin.Visible = true;
                }
            }
            if(Mode.Equals(MODE_INFO))
            {
                plcViewDetails.Visible = true;
                if (user_status.Equals(VUIfunctions.VUI_USERTYPE_NONE))
                {
                    plcLoggedOut.Visible = true;
                    plcLoggedIn.Visible = false;
                }
                else
                {
                    PopulateLoggedInInfo(m);
                    plcLoggedIn.Visible = true;
                    plcLoggedOut.Visible = false;
                }
            }
        }

        protected void PopulateLoggedInInfo(Member m)
        {
            litUser.Text = m.LoginName;
        }

        protected void Logout_Click(object sender, EventArgs e)
        {
            Member m = VUIfunctions.CurrentUser();
            if (m != null)
            {
                Member.RemoveMemberFromCache(m.Id);
                Member.ClearMemberFromClient(m.Id);
            }
            Session.Abandon();
            FormsAuthentication.SignOut();
            Response.Redirect(umbraco.library.NiceUrl(VUIfunctions.VUIMediaRootNode));
        }

        protected void Login_Click(object sender, EventArgs e)
        {
            Response.Redirect(umbraco.library.NiceUrl(VUIfunctions.VUIMediaRootNode));
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPassword.Text;

            try
            {
                bool LoggedIn = VUIfunctions.MemberLogin(email, password);

                if (LoggedIn)
                {
                    Response.Redirect(umbraco.library.NiceUrl(VUIfunctions.VUIMediaRootNode));
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                string result = ex.Message;
                litError.Text = result;
            }
        }
    }
}