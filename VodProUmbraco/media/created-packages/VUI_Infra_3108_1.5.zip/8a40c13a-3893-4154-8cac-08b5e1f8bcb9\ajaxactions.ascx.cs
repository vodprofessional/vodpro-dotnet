﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using umbraco;
using umbraco.cms;
using umbraco.presentation;
using umbraco.BusinessLogic;
using umbraco.cms.businesslogic.web;
using umbraco.NodeFactory;
using umbraco.cms.businesslogic.member;
using umbraco.cms.businesslogic.propertytype;
using System.Web.Security;
using VUI.classes;

namespace VUI.usercontrols
{
    public partial class ajaxactions : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string _action = Request.QueryString["a"];

            if (_action.Equals(ACTION_GET_IMAGES_FOR_SERVICE))
            {
                GetImagesForService();
            //    MemberLogin();
            }
            if (_action.Equals(ACTION_RATE_SERVICE))
            {
                RateService();
            }
            if (_action.Equals(ACTION_FAVOURITE_IMAGE))
            {
                FavouriteImage();
            }
            if (_action.Equals(ACTION_GET_ALL_SERVICE_LIST))
            {
                GetAllServiceList();
            }
            if (_action.Equals(ACTION_GET_SERVICE_LIST_BY_NAME))
            {
                GetServiceListByName();
            }
            if (_action.Equals(ACTION_GET_SERVICE_LIST_BY_NAME_AND_PLATFORM))
            {
                GetServiceListByServiceNameAndPlatform();
            }
            if (_action.Equals(ACTION_GET_SERVICE_LIST_BY_PLATFORM))
            {
                GetServiceListByPlatform();
            }
        }

        private void GetImagesForService()
        {
            // Make sure user is loggedin!!!

            int serviceid;
            if (Int32.TryParse(Request["service"], out serviceid))
            {
                Response.Write(VUIfunctions.ServiceWithImagesToJson(serviceid));
                // Response.Write(VUIfunctions.ImageListJson(serviceid));
            }
            else
            {
                Response.Write(VUIfunctions.ImageListJson(Request["service"]));
            }
        }

        private void FavouriteImage()
        {
            int imageid = -1;

            if (Int32.TryParse(Request["imageid"], out imageid))
            {
                Response.Write(VUIfunctions.FavouriteImage(imageid, Request["action"]));
            }
        }

        private void RateService()
        {
            int rating = -1;
            int serviceid = -1;

            if (Int32.TryParse(Request["rating"], out rating) && Int32.TryParse(Request["serviceid"], out serviceid))
            {
                Response.Write(VUIfunctions.RateService(serviceid, rating));
            }
        }


        private void GetServiceListByName()
        {
            string serviceName = Request["service"];
            if (!String.IsNullOrEmpty(serviceName))
            {
                Response.Write(VUIfunctions.ServiceListByNameToJson(serviceName));
            }
        }

        private void GetAllServiceList()
        {
            Response.Write(VUIfunctions.ServiceListByAllPlatformsToJson());
        }

        private void GetServiceListByPlatform()
        {
            int platformId = -1;
            if (Int32.TryParse(Request["platformid"], out platformId))
            {
                Response.Write(VUIfunctions.ServiceListByPlatformToJson(platformId));
            }
        }

        private void GetServiceListByServiceNameAndPlatform()
        {
            int platformId = -1;
            string serviceName = Request["service"];
            if (!String.IsNullOrEmpty(serviceName) && Int32.TryParse(Request["platformid"], out platformId))
            {
                Response.Write(VUIfunctions.ServiceListByNameAndPlatformToJson(serviceName, platformId));
            }
        }
        
        const string ACTION_GET_IMAGES_FOR_SERVICE = "si";
        const string ACTION_GET_SERVICE_LIST_BY_NAME = "sn";
        const string ACTION_GET_SERVICE_LIST_BY_PLATFORM = "sp";
        const string ACTION_GET_SERVICE_LIST_BY_NAME_AND_PLATFORM = "snp";
        const string ACTION_GET_ALL_SERVICE_LIST = "sa";
        const string ACTION_RATE_SERVICE = "rs";
        const string ACTION_FAVOURITE_IMAGE = "fi";
        const string ACTION_UNFAVOURITE_IMAGE = "ufi";

    }
}