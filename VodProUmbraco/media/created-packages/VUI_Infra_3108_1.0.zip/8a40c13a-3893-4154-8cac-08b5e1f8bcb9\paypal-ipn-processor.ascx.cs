﻿using System;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using uComponents.Core.DataTypes;
using umbraco.cms.businesslogic.member;
using umbraco.cms.businesslogic.property;
using VUI.classes;

namespace VUI.usercontrols
{
    public partial class paypal_ipn_processor : System.Web.UI.UserControl
    {

        private static log4net.ILog log = log4net.LogManager.GetLogger(typeof(vui_subscribe_process));

        protected void Page_Load(object sender, EventArgs e)
        {
            //Post back to either sandbox or live
            string strSandbox = "https://www.sandbox.paypal.com/cgi-bin/webscr";
            string strLive = "https://www.paypal.com/cgi-bin/webscr";
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(strSandbox);

            log.Debug("Processing message from PayPal");

            //Set values for the request back
            req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded";
            byte[] param = Request.BinaryRead(HttpContext.Current.Request.ContentLength);
            string strRequest = Encoding.ASCII.GetString(param);

            log.Debug("Message:" + strRequest);

            strRequest += "&cmd=_notify-validate";
            req.ContentLength = strRequest.Length;


            //for proxy
            //WebProxy proxy = new WebProxy(new Uri("http://url:port#"));
            //req.Proxy = proxy;

            //Send the request to PayPal and get the response
            StreamWriter streamOut = new StreamWriter(req.GetRequestStream(), System.Text.Encoding.ASCII);
            streamOut.Write(strRequest);
            streamOut.Close();


            StreamReader streamIn = new StreamReader(req.GetResponse().GetResponseStream());
            string strResponse = streamIn.ReadToEnd();
            streamIn.Close();


            log.Debug("Response:" + strResponse);


            if (strResponse == "VERIFIED")
            {
                //check the payment_status is Completed
                //check that txn_id has not been previously processed
                //check that receiver_email is your Primary PayPal email
                //check that payment_amount/payment_currency are correct
                //process payment

                NameValueCollection qs = HttpUtility.ParseQueryString(strRequest);

                string txn_id = qs.Get("txn_id");
                string userid = qs.Get("custom"); // the user id is sent in the custom field
                
                // If all good:



                /*  txn_id = 61E67681CH3238416
                    payer_email = gm_1231902590_per@paypal.com
                    payer_id = LPLWNMTBWMFAY
                    payer_status = verified
                    first_name = Test
                    last_name = User
                    address_city = San Jose
                    address_country = United States
                    address_country_code = US
                    address_name = Test User
                    address_state = CA
                    address_status = confirmed
                    mc_fee = 0.88
                    mc_gross = 19.95
                    payment_date = 20:12:59 Jan 13, 2009 PST
                    payment_fee = 0.88
                    payment_gross = 19.95
                    payment_status = Completed Status, which determines whether the transaction is complete
                    payment_type = instant Kind of payment
                    protection_eligibility = Eligible
                    quantity = 1
                    shipping = 0.00
                    tax = 0.00
                    custom = Your custom field
                    handling_amount = 0.00
                    item_name =
                    item_number =
                    mc_currency = USD
                    mc_fee = 0.88
                    mc_gross = 19.95
                    payment_date = 20:12:59 Jan 13, 2009 PST
                    payment_fee = 0.88
                    payment_gross = 19.95
                    payment_status = Completed Status, which determines whether the transaction is
                    complete
                    payment_type = instant Kind of payment
                    protection_eligibility = Eligible
                    quantity = 1
                 */



            }
            else if (strResponse == "INVALID")
            {
                //log for manual investigation
            }
            else
            {
                //log response/ipn data for manual investigation
            }
        }
    }
}

