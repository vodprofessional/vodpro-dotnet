﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using VUI.classes;
using umbraco.cms.businesslogic.member;
using System.Text.RegularExpressions;

namespace VUI.usercontrols
{
    public partial class vui_public_user_admin : System.Web.UI.UserControl
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            Member m = VUIfunctions.CurrentUser();
            if (m == null)
            {
                Response.Redirect(VUIfunctions.VUI_subscribe_page);
                Response.End();
            }
            else if (VUIfunctions.MemberVUIStatus(m).Equals(VUIfunctions.VUI_USERTYPE_NONE) || VUIfunctions.MemberVUIStatus(m).Equals(VUIfunctions.VUI_USERTYPE_REGISTRANT))
            {
                Response.Redirect(VUIfunctions.VUI_subscribe_page);
                Response.End();
            }

            divDetailsMessage.Visible = false;
            divPwdMessage.Visible = false;
            plcAdministratorDetails.Visible = false;

            if (!IsPostBack)
            {
                PopulateUserDetails();
                GetVUIAdminDetails();

                if (VUIfunctions.CurrentMemberIsVUIAdmin())
                {
                    GetVUIUsers();
                    plcUsers.Visible = true;
                }
                else
                {
                    plcAdministratorDetails.Visible = true;
                }

                if (Session["UserShouldChangePassword"] != null)
                {
                    if ((bool)Session["UserShouldChangePassword"])
                    {
                        litDetailsMessage.Text = "You should change your password to something more memorable";
                        Session.Remove("UserShouldChangePassword");
                        divDetailsMessage.Visible = true;
                    }
                }

            }
            
        }

        protected void PopulateUserDetails()
        {
            Member m = VUIfunctions.CurrentUser();
            txtFirstName.Text = m.getProperty("firstName").Value.ToString();
            txtLastName.Text = m.getProperty("lastName").Value.ToString();
            txtEmail.Text = m.LoginName;



        }

        protected void ClearFormAndPopulateList()
        {
            txtVuiUserFirstname.Text = String.Empty;
            txtVuiUserLastname.Text = String.Empty;
            txtVuiEmail.Text = String.Empty;
            GetVUIUsers();
        }

        protected void GetVUIUsers()
        {
            List<Member> vuiusers = VUIfunctions.GetVUIUsersForAdmin(VUIfunctions.CurrentUser());
            rptVUIusers.DataSource = vuiusers;
            rptVUIusers.DataBind();

            litMaxUsers.Text = VUIfunctions.CurrentUser().getProperty("vUINumberOfUsersAllowed").Value.ToString();
            if (vuiusers.Count >= Int32.Parse(litMaxUsers.Text))
            {
                btnAddVUIUser.ToolTip = "You can't add more users";
                btnAddVUIUser.Enabled = false;
            }
        }

        protected void GetVUIAdminDetails()
        {
            Member m;
            if (VUIfunctions.CurrentMemberIsVUIAdmin())
            {
                m = VUIfunctions.CurrentUser();
            }
            else
            {
                m = VUIfunctions.GetVUIAdminForCurrentUser();
            }
            
            linkAdminName.Text = m.getProperty("fullName").Value.ToString();
            linkAdminName.NavigateUrl = @"mailto:" + m.Email;

            txtAccountType.Text = m.getProperty("vuiSubscriptionPackage").Value.ToString();
            txtStartDate.Text = m.getProperty("vuiJoinDate").Value.ToString();


        }

        protected void VUIUser_Bound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {

                Member m = (Member)e.Item.DataItem;
                Literal u = e.Item.FindControl("litUserDetails") as Literal;
                ((Button)(e.Item.FindControl("btnDeleteUser"))).CommandArgument = m.LoginName;
                u.Text = m.Email;
            }
        }

        private bool PasswordOk(string pwd)
        {
            return Regex.IsMatch(pwd, @"^.{6,}(?<=\d.*)(?<=[^a-zA-Z0-9].*)$");
        }

        protected void ChangePassword(object sender, EventArgs e)
        {
            litPwdErr.Text = "";
            litDetailsMessage.Text = "";

            List<string> errsPwd = new List<string>();
            

            if (String.IsNullOrEmpty(txtPassword1.Text) || String.IsNullOrWhiteSpace(txtPassword1.Text))
            {
                errsPwd.Add("You cannot have an empty password");
            }
            else if (txtPassword1.Text.Length < 6)
            {
                errsPwd.Add("That password is too short, enter something at least 6 characters long");
            }
            if (txtPassword1.Text.Length > 20)
            {
                errsPwd.Add("A password can have a maximum of 20 characters, you entered " + txtPassword1.Text.Length.ToString());
            }
            if (!PasswordOk(txtPassword1.Text))
            {
                errsPwd.Add("Your password should contain a mixture of letters and numbers and at least one funny character");
            }
            if (txtPassword1.Text != txtPassword2.Text)
            {
                errsPwd.Add("Darn it, your passwords didn't match!");
            }
            if (errsPwd.Count > 0)
            {
                litPwdErr.Text = String.Join("<br/>", errsPwd);
                divPwdMessage.Visible = true;
            }
            else
            {
                Member m = VUIfunctions.CurrentUser();
                m.Password = txtPassword1.Text;
                m.Save();
                litDetailsMessage.Text = "Password changed";
                divDetailsMessage.Visible = true;

            }
        }

        protected void UpdateDetails(object sender, EventArgs e)
        {
            List<string> msgs = new List<string>();

            if (String.IsNullOrEmpty(txtFirstName.Text) || String.IsNullOrWhiteSpace(txtFirstName.Text) ||
                String.IsNullOrEmpty(txtLastName.Text) || String.IsNullOrWhiteSpace(txtLastName.Text))
            {
                msgs.Add("Please enter your first and last names");
            }
            if (msgs.Count > 0)
            {
                litDetailsMessage.Text = String.Join("<br/>", msgs);
                divDetailsMessage.Visible = true;
            }
            else
            {
                Member m = VUIfunctions.CurrentUser();
                m.getProperty("firstName").Value = txtFirstName.Text;
                m.getProperty("lastName").Value = txtLastName.Text;
                m.getProperty("fullName").Value = txtFirstName.Text + " " + txtLastName.Text;
                m.Save();
                litDetailsMessage.Text = "Details changed";
                divDetailsMessage.Visible = true;
            }
        }


        // For Admins - Create vui_user
        protected void CreateVUIUser(object sender, EventArgs e) 
        {
            string firstname = txtVuiUserFirstname.Text;
            string lastname = txtVuiUserLastname.Text;
            string email = txtVuiEmail.Text;

            bool isValid = true;

            if (!VUIfunctions.IsEmail(email))
            {
                errEmail.Text = "Enter a valid email address";
                errEmail.Visible = true;
                isValid = false;
            }
            if (String.IsNullOrWhiteSpace(firstname) || String.IsNullOrWhiteSpace(lastname))
            {
                errName.Text = "Enter the user's first and last name";
                errName.Visible = true;
                isValid = false;
            }
            if (isValid)
            {
                string retval = VUIfunctions.CreateVUIuser(firstname, lastname, email);
                if (retval.Equals(VUIfunctions.VUI_USERADMIN_STATUS_SUCCESS) || retval.Equals(VUIfunctions.VUI_USERADMIN_STATUS_EXISTS))
                {
                    ClearFormAndPopulateList();
                }
                else
                {
                    errGeneral.Text = retval;
                    errGeneral.Visible = true;
                }
            }
        }



        protected void VUIUsers_Command(object sender, RepeaterCommandEventArgs e) 
        { 
            if(e.CommandName.Equals("DeleteVUIUser"))
            try
            {
                Membership.DeleteUser(e.CommandArgument.ToString());
                ClearFormAndPopulateList();
            }
            catch (Exception ex)
            {
                errGeneral.Text = "Error deleting user";
                errGeneral.Visible = true;
            }
        }

        protected void EditVUIUser(object sender, EventArgs e) { }



    }
}