﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using umbraco.cms.businesslogic.member;
using VUI.classes;
using umbraco.cms.businesslogic.property;
using uComponents.Core.DataTypes;
using umbraco.MacroEngines;
using System.Xml;
using umbraco.cms.businesslogic.web;
using System.Text;

namespace VUI.usercontrols
{
    public partial class vui_subscribe_process : System.Web.UI.UserControl
    {
        string ACTION = String.Empty;
        Member m = null;

        const string REDIRECT_HOME = "HOME";
        const string REDIRECT_SUBSCRIBE = "SUBSCRIBE";
        const string REDIRECT_THANKYOU = "THANKYOU";
        const string REDIRECT_LOGIN = "LOGIN";
        const string REDIRECT_CHECKOUT = "CHECKOUT";
        const string REDIRECT_FAIL = "FAIL";

        protected void Page_Load(object sender, EventArgs e)
        {
            m = VUIfunctions.CurrentUser();

            if (Request["VUIACTION"] != null)
            {
                ACTION = Request["VUIACTION"].ToString();
            }

            if (String.IsNullOrEmpty(ACTION))
            {
                Redirect(REDIRECT_SUBSCRIBE);
            }

            // BUY is triggered when the Buy Button on the Subscribe page is clicked
            if (ACTION.Equals("BUY"))
            {
                
                // Logged in
                if (m != null)
                {
                    string user_status = VUIfunctions.MemberVUIStatus(m);
                    
                    // THe user is already a VUI User or Administrator (Full Mode)
                    if (VUIfunctions.MemberVUIFullMode(user_status))
                    {
                        Redirect(REDIRECT_HOME);
                    }
                    else
                    {
                        InitiateBuy();
                        Redirect(REDIRECT_CHECKOUT);
                    }
                }
                // Not logged in - make them log in or register
                else
                {
                    Redirect(REDIRECT_LOGIN);
                }
            }

            // CHECKOUT is triggered when the PayPal Button on the Checkout page is clicked.
            if (ACTION.Equals("CHECKOUT"))
            {

                // Open the VUI_transation log item
                Document translog = new Document(VUIfunctions.VUI_transaction_log);
                int transactionNumber = (Int32)(translog.getProperty("transactionNumber").Value);
                transactionNumber += 1;
                translog.getProperty("transactionNumber").Value = transactionNumber;
                translog.Save();
                translog.Publish(VUIfunctions.u);

                
                // Iterate the tx number and save
                Document transaction = Document.MakeNew("VUI"+transactionNumber, DocumentType.GetByAlias("VUI_Transaction_Item"), VUIfunctions.u, VUIfunctions.VUI_transaction_log);
                transaction.getProperty("transactionNumber").Value = transactionNumber;
                transaction.getProperty("user").Value = m.Id;
                transaction.getProperty("status").Value = "INITIATED";
                transaction.getProperty("product").Value = "1-10 employees";
                transaction.getProperty("price").Value = 1234;
                transaction.getProperty("tax").Value = 146.5;
                transaction.Save();

                hid_invoice.Value = "VUI"+transactionNumber;               
                hid_custom.Value = "tx_item:" + transaction.Id;

                
                string userTransactions = m.getProperty("userTransactionLog").Value.ToString().Replace("{", "").Replace("}", "");

                StringBuilder sb = new StringBuilder("");
                
                int itemid = 0;
                int sortOrder = 0;
                if(!String.IsNullOrEmpty(userTransactions))
                {
                 /* <items>
                      <item id='2' sortOrder='0'>
                        <transactionNumber nodeName='Transaction Number' nodeType='-51'>1001</transactionNumber>
                        <status nodeName='Transaction' nodeType='1034'>3481</transaction>
                      </item>
                      <item id='3' sortOrder='1'>
                        <transactionNumber nodeName='Transaction Number' nodeType='-51'>1001</transactionNumber>
                        <transaction nodeName='Transaction' nodeType='1034'>3480</transaction>
                      </item>
                    </items>                 */ 

                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(userTransactions);

                    XmlNodeList transList;
                    transList = xml.SelectSingleNode("items").SelectNodes("item");

                    
                    foreach (XmlNode item in transList)
                    {
                        sb.Append(item.OuterXml);
                        itemid = Int32.Parse(item.Attributes["id"].Value);
                        sortOrder = Int32.Parse(item.Attributes["sortOrder"].Value);
                    }
                }
                itemid++; sortOrder++;

                sb.Append(@"<item id=""" + itemid + @""" sortOrder=""" + sortOrder + @""">");
                sb.Append(@"<transactionNumber nodeName=""Transaction Number"" nodeType=""-51"">" + transactionNumber + @"</transactionNumber>");
                sb.Append(@"<status nodeName=""Status"" nodeType=""-88"">INITIATED</status>");
                sb.Append(@"</item>");


                m.getProperty("userTransactionLog").Value = @"<items>" + sb.ToString() + @"</items>";
                m.Save();



                PayPalForm.Visible = true;
            }

        }


        protected void Redirect(string page)
        {

            Response.End();
        }

        protected void RedirectToPayPal()
        {

        }

        protected void InitiateBuy()
        {

        }

        protected void IsInBuyProcess()
        {

        }

        protected void DetermineProduct()
        {

        }


    }
}