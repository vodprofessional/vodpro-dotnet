﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Xml;
using umbraco.cms.businesslogic.member;
using umbraco.cms.businesslogic.web;
using umbraco.MacroEngines;
using VUI.classes;
using System.Web.Security;

namespace VUI.usercontrols
{
    public partial class paypal_ipn_processor : System.Web.UI.UserControl
    {

        private static log4net.ILog log = log4net.LogManager.GetLogger(typeof(vui_subscribe_process));

        protected void Page_Load(object sender, EventArgs e)
        {
            //Post back to either sandbox or live
            string strSandbox = "https://www.sandbox.paypal.com/cgi-bin/webscr";
            string strLive = "https://www.paypal.com/cgi-bin/webscr";
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(strSandbox);

            log.Debug("Processing message from PayPal");

            //Set values for the request back
            req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded";
            byte[] param = Request.BinaryRead(HttpContext.Current.Request.ContentLength);
            string strRequest = Encoding.ASCII.GetString(param);

            log.Debug("Message:" + strRequest);

            strRequest += "&cmd=_notify-validate";
            req.ContentLength = strRequest.Length;


            //for proxy
            //WebProxy proxy = new WebProxy(new Uri("http://url:port#"));
            //req.Proxy = proxy;

            //Send the request to PayPal and get the response
            StreamWriter streamOut = new StreamWriter(req.GetRequestStream(), System.Text.Encoding.ASCII);
            streamOut.Write(strRequest);
            streamOut.Close();


            StreamReader streamIn = new StreamReader(req.GetResponse().GetResponseStream());
            string strResponse = streamIn.ReadToEnd();
            streamIn.Close();


            log.Debug("Response:" + strResponse);


            if (strResponse == "VERIFIED")
            {


                System.Collections.Specialized.NameValueCollection qs = HttpUtility.ParseQueryString(strRequest);

                string paymentStatus = qs.Get("payment_status");

                if (paymentStatus.Equals("Pending"))
                {
                    paymentStatus = paymentStatus + " " + qs.Get("pending_reason");
                }

                log.Debug("Payment Status: " + paymentStatus);

                string receiver_email = qs.Get("receiver_email");
                string payer_email = qs.Get("payer_email");
                string txn_id = qs.Get("txn_id");
                string custom = qs.Get("custom");  //TtransactionNumber;transactionDocId"
                
                
                string transactionNumber = String.Empty;
                int txDocId;

                if(String.IsNullOrEmpty(custom))
                {
                    log.Debug("Can't process empty custom token");
                    return;
                }
                else
                {
                    try
                    {
                        string[] customTokens = custom.Split(';');
                        transactionNumber = customTokens[0];
                        Int32.TryParse(customTokens[1], out txDocId);

                        // Transaction
                        log.Debug("Opening transaction document:" + txDocId);
                        Document tx = new Document(txDocId);
                        int userId = (Int32)(tx.getProperty("user").Value);
                        string PRODUCTCODE = tx.getProperty("productID").Value.ToString();
                        tx.getProperty("status").Value = "PAYPAL " + paymentStatus;
                        tx.getProperty("payPalTXN").Value = txn_id;
                        tx.getProperty("payerEmail").Value = payer_email;
                        tx.getProperty("payPalReturnMessage").Value = strRequest;
                        tx.Save();

                        log.Debug("Saved transaction");

                        

                        // Member
                        Member m = new Member(userId);

                        // Transaction Log
                        string userTransactions = m.getProperty("userTransactionLog").Value.ToString().Replace("{", "").Replace("}", "");
                        StringBuilder sb = new StringBuilder("");

                        int itemid = 0;
                        int sortOrder = 0;
                        if (!String.IsNullOrEmpty(userTransactions))
                        {

                            XmlDocument xml = new XmlDocument();
                            xml.LoadXml(userTransactions);

                            XmlNodeList transList;
                            transList = xml.SelectSingleNode("items").SelectNodes("item");

                            foreach (XmlNode item in transList)
                            {
                                sb.Append(item.OuterXml);
                                itemid = Int32.Parse(item.Attributes["id"].Value);
                                sortOrder = Int32.Parse(item.Attributes["sortOrder"].Value);
                            }
                        }
                        itemid++; sortOrder++;

                        sb.Append(@"<item id=""" + itemid + @""" sortOrder=""" + sortOrder + @""">");
                        sb.Append(@"<transactionNumber nodeName=""Transaction Number"" nodeType=""-51"">" + transactionNumber + @"</transactionNumber>");
                        sb.Append(@"<status nodeName=""Status"" nodeType=""-88"">TO PAYPAL</status>");
                        sb.Append(@"<transactionDate nodeName=""Status"" nodeType=""-36"">" + DateTime.Now.ToString() + "</transactionDate>");
                        sb.Append(@"</item>");
                        m.getProperty("userTransactionLog").Value = @"<items>" + sb.ToString() + @"</items>";

                        // If Payment is Complete
                        if (paymentStatus.Equals("Complete"))
                        {

                            log.Debug("Getting product details: " + PRODUCTCODE);
                            DynamicNode product = (new DynamicNode(VUIfunctions.VUI_product_list)).Descendants("VUISubscriptionProduct").Items.Where(n => n.GetProperty("productCode").Value.ToUpper().Equals(PRODUCTCODE)).ToList().First();
                        
                            m.getProperty("activeSubscriptionTransaction").Value = transactionNumber;
                            m.getProperty("viuFullyPaidUp").Value = true;
                            m.getProperty("vuiJoinDate").Value = DateTime.Today;
                            m.getProperty("vUINumberOfUsersAllowed").Value = product.GetProperty("basicNumberOfUsers").Value;
                            Roles.AddUserToRole(m.LoginName, "vui_administrator");
                            log.Debug("Congratulations " + m.LoginName + " on becoming a subscriber. Need to send Email here!");
                        }
                        m.Save();
                    }
                    catch (Exception ex)
                    {
                        log.Error("Error processing payment:",ex);
                    }
                }

                /*
                 * mc_gross=3354.00&protection_eligibility=Eligible&address_status=confirmed&payer_id=PWBSZR2LUF84A&                 * tax=559.00&address_street=1+Main+St&payment_date=04%3A49%3A51+Aug+31%2C+2012+PDT                 * &payment_status=Pending                 * &charset=windows-1252                 * &address_zip=95131                 * &first_name=Oliver                 * &option_selection1=11-50+employees                 * &address_country_code=US                 * &address_name=Oliver+Wood                 * &notify_version=3.6&custom=                 * &payer_status=verified&                 * business=oliver_1346325251_biz%40vodprofessional.com                 * &address_country=United+States                 * &address_city=San+Jose                 * &quantity=1                 * &verify_sign=Ap3FC719E7Kr4AYVtEg6NGgQt6O8AwMSbIpYSgHWgX4PtaBFLGXs6pSx                 * &payer_email=nice_1345646315_per%40vodprofessional.com                 * &option_name1=Company+size                 * &txn_id=6LA12424N5363721F                 * &payment_type=instant                 * &last_name=Wood                 * &address_state=CA                 * &receiver_email=oliver_1346325251_biz%40vodprofessional.com                 * &receiver_id=9WZPQ6XAT9UWE                 * &pending_reason=multi_currency                 * &txn_type=web_accept                 * &item_name=VUI+Library+Subscription+%2812+Months%29                 * &mc_currency=GBP                 * &item_number=VUI001                 * &residence_country=US                 * &test_ipn=1                 * &handling_amount=0.00                 * &transaction_subject=VUI+Library+Subscription+%2812+Months%29&payment_gross=&shipping=0.00                 * &ipn_track_id=b161232692cfa                 */
                
                /*  txn_id = 61E67681CH3238416
                    payer_email = gm_1231902590_per@paypal.com
                    payer_id = LPLWNMTBWMFAY
                    payer_status = verified
                    first_name = Test
                    last_name = User
                    address_city = San Jose
                    address_country = United States
                    address_country_code = US
                    address_name = Test User
                    address_state = CA
                    address_status = confirmed
                    mc_fee = 0.88
                    mc_gross = 19.95
                    payment_date = 20:12:59 Jan 13, 2009 PST
                    payment_fee = 0.88
                    payment_gross = 19.95
                    payment_status = Completed Status, which determines whether the transaction is complete
                    payment_type = instant Kind of payment
                    protection_eligibility = Eligible
                    quantity = 1
                    shipping = 0.00
                    tax = 0.00
                    custom = Your custom field
                    handling_amount = 0.00
                    item_name =
                    item_number =
                    mc_currency = USD
                    mc_fee = 0.88
                    mc_gross = 19.95
                    payment_date = 20:12:59 Jan 13, 2009 PST
                    payment_fee = 0.88
                    payment_gross = 19.95
                    payment_status = Completed Status, which determines whether the transaction is
                    complete
                    payment_type = instant Kind of payment
                    protection_eligibility = Eligible
                    quantity = 1
                 */



            }
            else if (strResponse == "INVALID")
            {
                log.Debug(strResponse + " Something went wrong with the IPN conversation");
            }
            else
            {
                //log response/ipn data for manual investigation
                log.Debug(strResponse + " Something went wrong with the IPN conversation");
            }
        }
    }
}

