﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VUI.classes;
using System.Web.Security;
using umbraco.cms.businesslogic.member;

namespace VUI.usercontrols
{
    public partial class vui_membership : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GetUsers(object sender, EventArgs e)
        {
            VUIfunctions vf = new VUIfunctions();

            List<Member> admins = vf.GetVUIAdmins();

            litUsers.Text = "";
            foreach (Member admin in admins)
            {
                litUsers.Text += admin.Id.ToString() + " " + admin.Email + "<br/>";
                List<Member> users = vf.GetVUIUsersForAdmin(admin);
                foreach(Member user in users)
                {
                    litUsers.Text += " - " + user.Id.ToString() + " " + user.Email + "<br/>";
                }
             /* */
            }
        }

    }
}