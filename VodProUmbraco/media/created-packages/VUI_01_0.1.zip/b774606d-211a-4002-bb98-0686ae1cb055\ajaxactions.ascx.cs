﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using umbraco;
using umbraco.cms;
using umbraco.presentation;
using umbraco.BusinessLogic;
using umbraco.cms.businesslogic.web;
using umbraco.NodeFactory;
using umbraco.cms.businesslogic.member;
using umbraco.cms.businesslogic.propertytype;
using System.Web.Security;
using VUI.classes;

namespace VUI.usercontrols
{
    public partial class ajaxactions : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string _action = Request.QueryString["a"];

            if (_action.Equals("si"))
            {
                GetImagesForService();
            //    MemberLogin();
            }
        }

        private void GetImagesForService()
        {
            VUIfunctions vf = new VUIfunctions();
            int serviceid;
            if (Int32.TryParse(Request["service"], out serviceid))
            {
                Response.Write(vf.ImageListJson(serviceid));
            }
            else
            {
                Response.Write(vf.ImageListJson(Request["service"]));
            }
        }

    }
}