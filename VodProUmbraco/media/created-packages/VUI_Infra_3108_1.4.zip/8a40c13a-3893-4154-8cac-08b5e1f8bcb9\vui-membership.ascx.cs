﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VUI.classes;
using System.Web.Security;
using umbraco.cms.businesslogic.member;

namespace VUI.usercontrols
{
    public partial class vui_membership : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            bool showRegistrantButton = ConfigurationManager.AppSettings["MEM_allowSetAllAsRegistrants"].ToString().Equals("true");
            if(showRegistrantButton)
            {
                pnlRegistrant.Visible = true;
            }
        }

        protected void AddRegistrant_Click(object sender, EventArgs e)
        {
            MemberGroup mg = MemberGroup.GetByName("registrant");
            List<Member> ms = Member.GetAllAsList().ToList();
            foreach (Member m in ms)
            {
                m.AddGroup(mg.Id);
            }

            ConfigurationManager.AppSettings["MEM_allowSetAllAsRegistrants"] = "false";
        }

        protected void GetUsers(object sender, EventArgs e)
        {

            List<Member> admins = VUIfunctions.GetVUIAdmins();

            litUsers.Text = "";
            foreach (Member admin in admins)
            {
                litUsers.Text += admin.Id.ToString() + " " + admin.Email + "<br/>";
                List<Member> users = VUIfunctions.GetVUIUsersForAdmin(admin);
                foreach(Member user in users)
                {
                    litUsers.Text += " - " + user.Id.ToString() + " " + user.Email + "<br/>";
                }
             /* */
            }
        }

    }
}